package com.rootscope.scanner

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var scanButton: Button
    private lateinit var exportButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private var latestReport = JSONObject()
    private var latestText = "Сначала запустите сканирование."
    private val createJson = registerForActivityResult(
        android.app.ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write(latestReport.toString(2).toByteArray(Charsets.UTF_8))
                }
                output.text = latestText + "\n\nJSON сохранён."
            } catch (e: Exception) {
                output.text = latestText + "\n\nОшибка экспорта: ${e.message}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF10151D.toInt())
        }
        val title = TextView(this).apply {
            text = "RootScope"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Диагностика Android • только чтение"
            textSize = 14f
            setTextColor(0xFFB8C4D6.toInt())
            setPadding(0, 4, 0, 16)
        }
        scanButton = Button(this).apply {
            text = "Запустить глубокую диагностику"
            setOnClickListener { scan() }
        }
        exportButton = Button(this).apply {
            text = "Экспортировать JSON"
            isEnabled = false
            setOnClickListener {
                createJson.launch("RootScope-${System.currentTimeMillis()}.json")
            }
        }
        output = TextView(this).apply {
            text = "Нажмите «Запустить глубокую диагностику».\n\n" +
                "Приложение не получает root, не разблокирует загрузчик, не прошивает разделы " +
                "и не запускает эксплойты. Android ограничивает доступ к части системных данных."
            textSize = 13.5f
            setTextColor(0xFFE5EAF1.toInt())
            setTextIsSelectable(true)
            setPadding(0, 18, 0, 24)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(scanButton)
        outer.addView(exportButton)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }

    private fun scan() {
        scanButton.isEnabled = false
        exportButton.isEnabled = false
        output.text = "Сканирование…\nСбор доступных системных сведений."
        executor.execute {
            val report = collect()
            val rendered = render(report)
            runOnUiThread {
                latestReport = report
                latestText = rendered
                output.text = rendered
                scanButton.isEnabled = true
                exportButton.isEnabled = true
            }
        }
    }

    private fun collect(): JSONObject {
        val root = JSONObject()
        root.put("app", JSONObject()
            .put("name", "RootScope")
            .put("version", "1.0")
            .put("scanTime", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
            .put("mode", "read-only; no exploit execution"))
        val device = JSONObject()
        device.put("manufacturer", Build.MANUFACTURER)
        device.put("brand", Build.BRAND)
        device.put("model", Build.MODEL)
        device.put("device", Build.DEVICE)
        device.put("product", Build.PRODUCT)
        device.put("hardware", Build.HARDWARE)
        device.put("board", Build.BOARD)
        device.put("bootloader", Build.BOOTLOADER)
        device.put("androidRelease", Build.VERSION.RELEASE)
        device.put("sdkInt", Build.VERSION.SDK_INT)
        device.put("securityPatch", Build.VERSION.SECURITY_PATCH)
        device.put("buildId", Build.ID)
        device.put("display", Build.DISPLAY)
        device.put("fingerprint", Build.FINGERPRINT)
        device.put("tags", Build.TAGS)
        device.put("type", Build.TYPE)
        device.put("abis", JSONArray(Build.SUPPORTED_ABIS.toList()))
        device.put("kernel", readText("/proc/version"))
        root.put("device", device)

        val props = readGetprop()
        val wanted = listOf(
            "ro.boot.verifiedbootstate", "ro.boot.flash.locked", "ro.boot.vbmeta.device_state",
            "ro.boot.vbmeta.avb_version", "ro.boot.avb_version", "ro.boot.bootloader",
            "ro.boot.slot_suffix", "ro.boot.slot", "ro.bootmode", "ro.debuggable", "ro.secure",
            "ro.build.version.security_patch", "ro.build.fingerprint", "ro.build.tags",
            "ro.build.type", "ro.build.version.release", "ro.build.version.sdk",
            "ro.product.model", "ro.product.device", "ro.hardware", "persist.sys.usb.config",
            "sys.usb.config", "init.svc.adbd", "ro.crypto.state", "ro.crypto.type",
            "ro.kernel.qemu", "ro.build.version.incremental"
        )
        val selected = JSONObject()
        wanted.forEach { key -> props[key]?.let { selected.put(key, it) } }
        root.put("systemProperties", selected)
        root.put("allReadableProperties", JSONObject(props.toSortedMap() as Map<*, *>))

        val boot = JSONObject()
        boot.put("verifiedBootState", props["ro.boot.verifiedbootstate"] ?: "недоступно")
        boot.put("flashLocked", props["ro.boot.flash.locked"] ?: "недоступно")
        boot.put("vbmetaDeviceState", props["ro.boot.vbmeta.device_state"] ?: "недоступно")
        boot.put("buildTags", Build.TAGS)
        boot.put("interpretation", interpretBoot(props))
        boot.put("fastbootRuntimeStatus", "Нельзя достоверно определить из обычного Android-сеанса")
        root.put("verifiedBoot", boot)

        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/vendor/bin/su",
            "/system/app/Superuser.apk", "/data/adb/magisk", "/data/adb/ksu",
            "/data/adb/ap", "/debug_ramdisk"
        )
        val pathResults = JSONArray()
        paths.forEach { p -> pathResults.put(JSONObject()
            .put("path", p)
            .put("existsAndReadable", try { File(p).exists() && File(p).canRead() } catch (_: Exception) { false })
            .put("note", "Отсутствие признака не доказывает отсутствие root; часть путей закрыта песочницей")) }
        root.put("rootIndicators", JSONObject()
            .put("testPaths", pathResults)
            .put("rootPackages", findRootPackages())
            .put("assessment", "Наличие su/пакета — индикатор, не доказательство. Проверка не пытается получить привилегии."))

        val security = JSONObject()
        security.put("selinuxEnforce", readText("/sys/fs/selinux/enforce")?.trim() ?: "недоступно")
        security.put("procCmdline", readText("/proc/cmdline")?.take(8000) ?: "недоступно")
        security.put("mounts", readText("/proc/mounts")?.lineSequence()
            ?.filter { it.contains(" /system ") || it.contains(" /vendor ") || it.contains(" /product ") ||
                it.contains(" /odm ") || it.contains(" / ") || it.contains(" /metadata ") }
            ?.take(120)?.joinToString("\n") ?: "недоступно")
        security.put("adbEnabledSetting", try {
            Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, -1)
        } catch (_: Exception) { -1 })
        security.put("unknownSourcesForThisApp", try {
            if (Build.VERSION.SDK_INT >= 26) packageManager.canRequestPackageInstalls() else false
        } catch (_: Exception) { false })
        root.put("securityAndInterfaces", security)

        val patch = Build.VERSION.SECURITY_PATCH
        root.put("vulnerabilityReview", JSONObject()
            .put("securityPatch", patch)
            .put("assessment", "Локальная проверка не подтверждает CVE: для точного сопоставления нужны официальные бюллетени производителя и Android для данной модели/сборки.")
            .put("limitations", JSONArray(listOf(
                "Номер патча сам по себе не доказывает наличие или отсутствие конкретной CVE.",
                "Закрытые vendor-компоненты и backport-исправления обычному приложению не видны.",
                "Эксплойты не запускаются; тестирование уязвимостей не выполняется."
            )))
            .put("officialSources", JSONArray(listOf(
                "https://source.android.com/docs/security/bulletin",
                "https://www.iqoo.com/",
                "https://source.android.com/docs/security/features/verifiedboot"
            ))))

        val packages = JSONArray()
        try {
            @Suppress("DEPRECATION")
            val installed = packageManager.getInstalledPackages(0)
            installed.map { it.packageName }.sorted().forEach { packages.put(it) }
        } catch (e: Exception) {
            packages.put("Не удалось перечислить пакеты: ${e.message}")
        }
        root.put("installedPackages", packages)
        root.put("limitations", JSONArray(listOf(
            "Данные отражают только то, что доступно этому приложению без root.",
            "Обычное приложение не может гарантированно читать все bootloader/vbmeta/vendor-параметры.",
            "Состояние fastboot требует отдельного подключения/сеанса и здесь не проверяется.",
            "Невозможность прочитать SELinux или системный путь не означает, что защита отключена."
        )))
        return root
    }

    private fun readGetprop(): Map<String, String> {
        val out = linkedMapOf<String, String>()
        try {
            val p = ProcessBuilder("/system/bin/getprop").redirectErrorStream(true).start()
            p.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val m = Regex("^\\[([^]]+)]: \\[(.*)]$").find(line)
                    if (m != null) out[m.groupValues[1]] = m.groupValues[2]
                }
            }
            p.waitFor()
        } catch (_: Exception) { }
        return out
    }

    private fun readText(path: String): String? = try {
        File(path).takeIf { it.canRead() }?.readText()?.take(20000)
    } catch (_: Exception) { null }

    private fun findRootPackages(): JSONArray {
        val terms = listOf("magisk", "kernelsu", "apatch", "superuser", "supersu", "rootcloak")
        val result = JSONArray()
        try {
            @Suppress("DEPRECATION")
            packageManager.getInstalledPackages(0).map { it.packageName }.sorted()
                .filter { pkg -> terms.any { pkg.lowercase(Locale.ROOT).contains(it) } }
                .forEach { result.put(it) }
        } catch (_: Exception) { }
        return result
    }

    private fun interpretBoot(props: Map<String, String>): String {
        val vb = props["ro.boot.verifiedbootstate"]
        val locked = props["ro.boot.flash.locked"]
        val vbmeta = props["ro.boot.vbmeta.device_state"]
        return when {
            vb == "green" && locked == "1" && vbmeta == "locked" ->
                "Свойства согласуются с locked/green Verified Boot; это не независимая аппаратная аттестация."
            vb == "orange" || locked == "0" || vbmeta == "unlocked" ->
                "Есть свойство, указывающее на разблокированное состояние или предупреждающий статус; перепроверьте данные производителя."
            else -> "Недостаточно доступных свойств для уверенного вывода."
        }
    }

    private fun render(j: JSONObject): String {
        val d = j.optJSONObject("device") ?: JSONObject()
        val vb = j.optJSONObject("verifiedBoot") ?: JSONObject()
        val root = j.optJSONObject("rootIndicators") ?: JSONObject()
        val sec = j.optJSONObject("securityAndInterfaces") ?: JSONObject()
        val props = j.optJSONObject("systemProperties") ?: JSONObject()
        val b = StringBuilder()
        b.appendLine("ROOTSCOPE — ОТЧЁТ ДИАГНОСТИКИ")
        b.appendLine("Время: ${j.optJSONObject("app")?.optString("scanTime")}")
        b.appendLine()
        b.appendLine("УСТРОЙСТВО И СБОРКА")
        listOf("manufacturer","brand","model","device","product","hardware","board","bootloader",
            "androidRelease","sdkInt","securityPatch","buildId","display","fingerprint","tags","type","kernel")
            .forEach { b.appendLine("$it: ${d.optString(it, "недоступно")}") }
        b.appendLine()
        b.appendLine("VERIFIED BOOT / ЗАГРУЗЧИК")
        b.appendLine("verifiedBootState: ${vb.optString("verifiedBootState")}")
        b.appendLine("flashLocked: ${vb.optString("flashLocked")}")
        b.appendLine("vbmetaDeviceState: ${vb.optString("vbmetaDeviceState")}")
        b.appendLine(vb.optString("interpretation"))
        b.appendLine("Fastboot: ${vb.optString("fastbootRuntimeStatus")}")
        b.appendLine()
        b.appendLine("ROOT-ПРИЗНАКИ")
        b.appendLine("Пакеты-кандидаты: ${root.optJSONArray("rootPackages")?.toString() ?: "[]"}")
        b.appendLine(root.optString("assessment"))
        b.appendLine()
        b.appendLine("БЕЗОПАСНОСТЬ / ИНТЕРФЕЙСЫ")
        b.appendLine("SELinux enforce: ${sec.optString("selinuxEnforce")}")
        b.appendLine("ADB enabled setting: ${sec.opt("adbEnabledSetting")}")
        b.appendLine("Параметры загрузки: ${sec.optString("procCmdline")}")
        b.appendLine()
        b.appendLine("КЛЮЧЕВЫЕ СИСТЕМНЫЕ СВОЙСТВА")
        props.keys().asSequence().sorted().forEach { b.appendLine("$it = ${props.optString(it)}") }
        b.appendLine()
        b.appendLine("АНАЛИЗ УЯЗВИМОСТЕЙ")
        b.appendLine(j.optJSONObject("vulnerabilityReview")?.optString("assessment"))
        b.appendLine()
        b.appendLine("ОГРАНИЧЕНИЯ")
        val limits = j.optJSONArray("limitations")
        if (limits != null) for (i in 0 until limits.length()) b.appendLine("• ${limits.optString(i)}")
        b.appendLine()
        b.appendLine("Полный отчёт JSON содержит перечень доступных пакетов, разделов и всех прочитанных свойств.")
        return b.toString()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
